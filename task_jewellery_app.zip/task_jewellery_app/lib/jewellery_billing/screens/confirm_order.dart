import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/utils/app_components.dart';

import '../../utils/appColours.dart';



class ConfirmOrder extends StatefulWidget {
  const ConfirmOrder({super.key});

  @override
  State<ConfirmOrder> createState() => _ConfirmOrderState();
}

class _ConfirmOrderState extends State<ConfirmOrder> {

  bool status = false;
  void appSnackbar({required String title,required String message, required bool success }) {
    Color backgroundColor;
    switch (success) {
      case true:
        backgroundColor = Colors.green;
        break;
      case false:
        backgroundColor = Colors.blue;
        break;
    }
    Get.closeAllSnackbars();
    Get.snackbar(margin: const EdgeInsets.all(16),
      title,
      message,
      duration: const Duration(seconds: 4),
      snackPosition: SnackPosition.TOP,
      backgroundColor: backgroundColor,
      colorText: Colors.black,
    );
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: AppColours.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Confirm Order",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
              onTap: () {
                Get.back();
              },
              child:   Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 24.0.h,),
            Center(
          child: Container(
          height: Get.height*0.16,
            width: Get.width*0.4,
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16.r),
              border: Border.all(color: const Color(0xFFE0B7FF), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.purple.shade100.withOpacity(0.3),
                  blurRadius: 10,
                  spreadRadius: 1,
                )
              ],
            ),
            child: Container(
              height: Get.height*0.1,
              width: Get.width*0.2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                color: Colors.white,
              ),
              child: Image(
                image: NetworkImage("https://m.media-amazon.com/images/I/711F8TIUaLL._AC_UY1100_.jpg"), // Replace with your image asset
                fit: BoxFit.contain,
              ),
            ),
          ),
        ),
            SizedBox(height: 8.0.h,),
            Padding(
              padding: const EdgeInsets.only(right: 12.0,left: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    '₹36,390',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 18.0.sp,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,

                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    'Joyalukkas 22 k (916) Rough Dazzling Mens Gold Ring ',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 14.0.sp,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.w600
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    'discount - 12%',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 12.0.sp,
                      color: Colors.green,
                    ),),Text(
                    'Include - tax',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 12.0.sp,
                      color: Colors.redAccent,
                    ),)
                ],
              ),
            ),
            SizedBox(height: 16.0.h,),
            commonTextField(name: "Customer name", prefixIcon:  Icon(Icons.account_circle_rounded,color: AppColours.fieldT,), label: "Enter the customer name"),
            SizedBox(height: 10.0.h,),
            commonTextField(name: "Customer phone", prefixIcon:  Icon(Icons.call,color: AppColours.fieldT,), label: "Enter the customer phone"),
            SizedBox(height: 10.0.h,),
            commonTextField(name: "Customer address", prefixIcon:  Icon(Icons.location_on,color: AppColours.fieldT,), label: "Enter the customer address"),
            SizedBox(height: 24.0.h,),
            commonButton(text: "Place the order", onTap: (){
              appSnackbar(title: 'Hi Developer, im Hirthick', message: 'In short period of time i cant able to finish the app sorry...😔', success: false);
              setState(() {
              status = !status;
            });}),
            SizedBox(height: 16.0.h,),
            status?
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text("Generating invoice...",
                  style: GoogleFonts.nunitoSans(
                    fontSize: 18.0.sp,
                    fontWeight: FontWeight.w800,
                    color: Colors.black,

                  ),),
                SizedBox(height: 10.0.h,),
                CircularProgressIndicator(
                  color: AppColours.purple,
                  strokeWidth: 3.5,
                ),
              ],
            ):SizedBox.shrink()

          ],
        ),
      ),
    );
  }
}
