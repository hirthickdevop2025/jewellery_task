import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/utils/app_components.dart';

import '../../utils/appColours.dart';
import '../../utils/order_widget.dart';


class BillsHistory extends StatefulWidget {
  const BillsHistory({super.key});

  @override
  State<BillsHistory> createState() => _BillsHistoryState();
}

class _BillsHistoryState extends State<BillsHistory> {
  void appSnackbar({required String title,required String message, required bool success }) {
    Color backgroundColor;
    switch (success) {
      case true:
        backgroundColor = Colors.green;
        break;
      case false:
        backgroundColor = Colors.blue;
        break;
    }
    Get.closeAllSnackbars();
    Get.snackbar(margin: const EdgeInsets.all(16),
      title,
      message,
      duration: const Duration(seconds: 2),
      snackPosition: SnackPosition.TOP,
      backgroundColor: backgroundColor,
      colorText: Colors.black,
    );
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    appSnackbar(title: 'Hi Developer, im Hirthick', message: 'In short period of time i cant able to finish the app sorry...😔', success: false);
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: AppColours.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Order history",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
              onTap: () {
                Get.back();
              },
              child:   Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text("Sales Dashboard", style: GoogleFonts.nunitoSans(
                fontSize: 14.0.sp,
                fontWeight: FontWeight.w800,
                color: AppColours.fieldT,

              ),),
            ),
            Padding(
              padding: const EdgeInsets.only(top:50.0),
              child: SizedBox(
                height: Get.height*0.2,
                child: PieChart(
                  PieChartData(
                    sections: _getSections(),
                    centerSpaceRadius: MediaQuery.of(context).size.width / 6,
                    sectionsSpace: 0,
                    centerSpaceColor: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: 24.0.h,),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                decoration: InputDecoration(
                  focusColor: Colors.white,
                  hintText: 'Search your Order...',
                  hintStyle: GoogleFonts.poppins(
                    fontSize: 10.5.sp,
                    color: Colors.grey[500],
                  ),
                  prefixIcon:  Icon(Icons.search_outlined,color: AppColours.fieldT,),
                  filled: true,
                  fillColor: Colors.white,
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: AppColours.grey),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  border: const OutlineInputBorder(
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),SizedBox(height: 6.0.h,),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text("Sales Dashboard", style: GoogleFonts.nunitoSans(
                fontSize: 14.0.sp,
                fontWeight: FontWeight.w800,
                color: AppColours.fieldT,

              ),),
            ),

            SizedBox(
              height: Get.height*0.5,
              child: ListView.builder(


                  itemBuilder: (context,index)=>   Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: OrderedCard(
                      orderNum: "ORD123456",
                      customerName: "Hirthick",
                      contact: "9876543210",
                      imageUrl: "https://m.media-amazon.com/images/I/711F8TIUaLL._AC_UY1100_.jpg", // Replace with actual image URL
                    ),
                  ),

                  itemCount: 12),
            ),
            // ListView(
            //   children: [
            //     OrderedCard(
            //       orderNum: "ORD123456",
            //       customerName: "Hirthick",
            //       contact: "9876543210",
            //       imageUrl: "https://example.com/product.jpg", // Replace with actual image URL
            //     ),
            //     OrderedCard(
            //       orderNum: "ORD123457",
            //       customerName: "Arun",
            //       contact: "9876543211",
            //       imageUrl: "https://example.com/another.jpg",
            //     ),
            //   ],
            // )


          ],
        ),
      ),
    );
  }
}



List<PieChartSectionData> _getSections() {
  double fontSize = 13.0.sp;
  double radius = Get.width * 0.1;
  return [
    PieChartSectionData(
      color: const Color(0xff007C13),
      value: 40,
      title: 'Bangles',
      radius: radius,
      titleStyle: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),
    PieChartSectionData(
      color:AppColours.skyBlue,
      value: 20,
      title: 'Chains',
      radius: radius,
      titleStyle: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
    ),
    PieChartSectionData(
      color: const Color(0xffBF0000),
      value: 20,
      title: 'Rings',
      radius: radius,
      titleStyle: GoogleFonts.poppins(
        fontSize: fontSize,
        fontWeight: FontWeight.w500,
        color: Colors.white,
      ),
    ),
  ];
}