import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/utils/app_components.dart';

import '../../utils/appColours.dart';





class AddProducts extends StatefulWidget {
  const AddProducts({super.key});

  @override
  State<AddProducts> createState() => _AddProductsState();
}

class _AddProductsState extends State<AddProducts> {
  void appSnackbar({required String title,required String message, required bool success }) {
    Color backgroundColor;
    switch (success) {
      case true:
        backgroundColor = Colors.green;
        break;
      case false:
        backgroundColor = Colors.blue;
        break;
    }
    Get.closeAllSnackbars();
    Get.snackbar(margin: const EdgeInsets.all(16),
      title,
      message,
      duration: const Duration(seconds: 2),
      snackPosition: SnackPosition.TOP,
      backgroundColor: backgroundColor,
      colorText: Colors.black,
    );
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    appSnackbar(title: 'Hi Developer, im Hirthick', message: 'In short period of time i cant able to finish the app sorry...😔', success: false);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColours.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Add Product",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
              onTap: () {
                Get.back();
              },
              child:   Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(

        child: Column(
          spacing: 12.0.h,
          children: [
            SizedBox(height: 20.0.h,),
            commonTextField(name: "Image Link", prefixIcon:  Icon(Icons.link,color: AppColours.fieldT,), label: "Paste the web link"),
            Padding(
              padding: const EdgeInsets.only(left: 16,right: 16),
              child:   Container(
                height: Get.height*0.1,
                width: Get.width*0.2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.r),
               color: AppColours.field,
                ),
                child: Image(
                  image: NetworkImage("https://m.media-amazon.com/images/I/711F8TIUaLL._AC_UY1100_.jpg"), // Replace with your image asset
                  fit: BoxFit.cover,
                ),
              ),
            ),
            commonTextField(name: "Rate", prefixIcon:  Icon(Icons.currency_rupee,color: AppColours.fieldT,), label: "Enter the price"),
            commonTextField(name: "Tax", prefixIcon:  Icon(Icons.money,color: AppColours.fieldT,), label: "Enter tax%"),
            commonTextField(name: "Category",
                suffix:  PopupMenuButton<String>(
              borderRadius: BorderRadius.circular(10),
              color: AppColours.white,
              onSelected: (value) {
                // handle your selected value
                print("Selected: $value");
              },
              child: Icon(Icons.keyboard_arrow_down,color: AppColours.fieldT,),
              itemBuilder: (context) => [
                ...['All', 'Earrings', 'Chains', 'Coins', 'Rings', 'Bangles'].map(
                      (item) => PopupMenuItem<String>(
                    height: Get.height * 0.04,
                    value: item,
                    child: Text(
                      item,
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w400,
                        fontSize: 12.0.sp,
                        color: AppColours.black,
                      ),
                    ),
                  ),
                ),
              ],
            ),
                label: "Select from the options", prefixIcon:  Icon(Icons.link,color: AppColours.field,)),
            SizedBox(height: 36.0.h,),
            commonButton(text: "Add product", onTap: (){})
          ],
        ),
      ),
    );
  }
}
