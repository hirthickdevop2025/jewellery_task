

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/authentication/screens/verification.dart';
import 'package:task_jewellery_app/utils/appColours.dart';

import '../../jewellery_billing/screens/confirm_order.dart';
import '../../utils/product_widget.dart';
import 'add_products.dart';


class MyProducts extends StatefulWidget {
  const MyProducts({super.key});



  @override
  State<MyProducts> createState() => _MyProductsState();
}

class _MyProductsState extends State<MyProducts> {
  int currentIndex = 0;
  final List<String> filterOptions = ['All', 'Earrings', 'Chains', 'Coins',"Rings","Bangles"];

 @override
  void initState() {
    // TODO: implement initState
    super.initState();
    appSnackbar(title: 'Hi Developer, im Hirthick', message: 'In short period of time i cant able to finish the app sorry...😔', success: false);
  }



  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        surfaceTintColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Our Products",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
              onTap: () {
                Get.back();
              },
              child: Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
    body: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
      children: [
        SizedBox(
          height: Get.height*0.045,
          width: Get.width*1,
          child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemBuilder: (context,index)=> GestureDetector(
                onTap: ()=> setState(() {
                  currentIndex = index;
                }),
                child: Container(
                  decoration: BoxDecoration(
                      color: currentIndex == index? AppColours.purple :AppColours.leaveField,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: currentIndex == index? AppColours.purple :AppColours.leaveField,width: 1)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 3.5,bottom: 3.5,left: 12,right:12 ),
                    child: Center(child: Text(filterOptions[index],style: GoogleFonts.nunitoSans(fontSize:14.0.sp,color: currentIndex == index? AppColours.white : AppColours.black),)),
                  ),
                ),
              ),
              separatorBuilder:(context,index)=> SizedBox(width: Get.width*0.02,),
              itemCount: filterOptions.length
          ),
        ),
        SizedBox(height: 16.h,),
        Expanded(
          child: ListView.separated(
              itemBuilder: (context,index)=> InkWell(
                  child: ProductCard(),
                  onTap: ()=>Get.to(ConfirmOrder()),
              ),
              separatorBuilder: (context,index)=> SizedBox(height: 10.h,),
              itemCount: 12
          ),
        )

      ],
      ),
    ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 80.0),
        child: InkWell(
          onTap: ()=> Get.to(AddProducts()),
          child: CircleAvatar(
            radius: 32.r,
            backgroundColor: AppColours.purple,
            child: Center(child: Icon(Icons.add,color: Colors.white,size: 40.0.w,)),
          ),
        ),
      ),
    );
  }

  void appSnackbar({required String title,required String message, required bool success }) {
    Color backgroundColor;
    switch (success) {
      case true:
        backgroundColor = Colors.green;
        break;
      case false:
        backgroundColor = Colors.blue;
        break;
    }
    Get.closeAllSnackbars();
    Get.snackbar(margin: const EdgeInsets.all(16),
      title,
      message,
      duration: const Duration(seconds: 2),
      snackPosition: SnackPosition.TOP,
      backgroundColor: backgroundColor,
      colorText: Colors.black,
    );
  }
}
