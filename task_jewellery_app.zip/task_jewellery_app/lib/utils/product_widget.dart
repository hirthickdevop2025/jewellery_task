import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/jewellery_management/screens/edit_product.dart';

import 'appColours.dart';

class ProductCard extends StatelessWidget {
  const ProductCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height*0.16,
      width: Get.width,
      padding: EdgeInsets.all(8.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: const Color(0xFFE0B7FF), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.purple.shade100.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 1,
          )
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
             height: Get.height*0.1,
              width: Get.width*0.2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                color: Colors.white,
              ),
              child: Image(
                image: NetworkImage("https://m.media-amazon.com/images/I/711F8TIUaLL._AC_UY1100_.jpg"), // Replace with your image asset
                fit: BoxFit.contain,
              ),
            ),
            SizedBox(width: 30.0.w,),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    '₹36,390',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 14.0.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    'Joyalukkas 22 k (916) Rough Dazzling Mens Gold Ring ',
                    style: GoogleFonts.nunitoSans(
                      fontSize: 12.0.sp,
                      color: Colors.grey.shade600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              Text(
                'discount - 12%',
                style: GoogleFonts.nunitoSans(
                  fontSize: 12.0.sp,
                  color: Colors.green,
                ),),Text(
                'Include - tax',
                style: GoogleFonts.nunitoSans(
                  fontSize: 12.0.sp,
                  color: Colors.redAccent,
                ),)
                ],
              ),
            ),

            PopupMenuButton<String>(
                borderRadius: BorderRadius.circular(10),
                color: AppColours.white,
                onSelected: (value) {

                },
                child:   Align(
                    alignment: Alignment.topRight,
                    child: Icon(Icons.more_vert,color: Colors.black,size: 20.0.w,)
                ),
                itemBuilder: (context) => [
                  PopupMenuItem(
                      height: Get.height * 0.02,
                      value: null,
                      child: InkWell(
                        onTap: (){Get.to(EditProduct());},
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                                "Edit",
                                style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12.0.sp,
                                    color: AppColours.black)
                            ),
                            Icon(Icons.edit,color:AppColours.black, )
                          ],
                        ),
                      )
                  ),
                  const PopupMenuDivider(),
                  PopupMenuItem(
                      height: Get.height * 0.02,
                      value:  null,
                      onTap: (){

                      }
                      ,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                              "Delete",
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w400,
                                fontSize: 12.0.sp,
                                color: Colors.red,)
                          ),
                         Icon(Icons.delete,color:Colors.red, )
                        ],
                      )),

                ]
            )
          ],
        ),
      ),
    );
  }
}
