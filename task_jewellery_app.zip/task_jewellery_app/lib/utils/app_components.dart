
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';

import 'appColours.dart';

Widget commonTextField({
  required name,
  required prefixIcon,
  required label,
  suffix

}) {
  return Padding(
    padding: const EdgeInsets.only(left: 16,right: 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          name,
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w500, fontSize: 14.0.sp),
        ),
        TextFormField(
          style:GoogleFonts.poppins(
              color: AppColours.black,
              fontWeight: FontWeight.w500,
              fontSize: 12.0.sp) ,
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(vertical: 15),
              prefixIcon: prefixIcon,
              filled: true,
              enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(10)),
              focusedBorder:  OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.transparent),
                  borderRadius: BorderRadius.circular(10)),
              fillColor: AppColours.field,
              border: InputBorder.none,
              hintText: label,
              suffixIcon: suffix,
              hintStyle: GoogleFonts.poppins(
                  color: AppColours.fieldT,
                  fontWeight: FontWeight.w400,
                  fontSize: 10.0.sp),
            )),
      ],
    ),
  );
}

class CommonPasswordField extends StatefulWidget {
  final String name;
  final String label;
  final Widget prefixIcon;

  const CommonPasswordField({
    super.key,
    required this.name,
    required this.prefixIcon,
    required this.label,
  });

  @override
  State<CommonPasswordField> createState() => _CommonPasswordFieldState();
}

class _CommonPasswordFieldState extends State<CommonPasswordField> {
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16,right: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.name,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w500,
              fontSize: 14.0.sp,
            ),
          ),
          TextFormField(
            obscureText: _obscureText,
            style: GoogleFonts.poppins(
              color: AppColours.black,
              fontWeight: FontWeight.w500,
              fontSize: 12.0.sp,
            ),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.symmetric(vertical: 15),
              prefixIcon: widget.prefixIcon,
              suffixIcon: IconButton(
                icon: Icon(
                  _obscureText ? Icons.visibility_off : Icons.visibility,
                  color: AppColours.fieldT,
                ),
                onPressed: () {
                  setState(() {
                    _obscureText = !_obscureText;
                  });
                },
              ),
              filled: true,
              fillColor: AppColours.field,
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Colors.transparent),
                borderRadius: BorderRadius.circular(10),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Colors.transparent),
                borderRadius: BorderRadius.circular(10),
              ),
              hintText: widget.label,
              hintStyle: GoogleFonts.poppins(
                color: AppColours.fieldT,
                fontWeight: FontWeight.w400,
                fontSize: 10.0.sp,
              ),
            ),
          ),
        ],
      ),
    );
  }
}


Widget commonButton({required text, required onTap}) {
  return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16),
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
              color: AppColours.purple,
              borderRadius: BorderRadius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.all(11),
            child: Center(
              child: Text(
                text,
                style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontSize: 16.0.sp),
              ),
            ),
          ),
        ),
      ));
}
