

import 'package:flutter/material.dart';

class AppColours{

  static const Color skyBlue = Color(0xff9AE1FF);
  static const Color textfieldbg = Color(0xffE8E8E8);

  static const Color green = Color(0xff9DFFBC);
  static const Color orange = Color(0xffFFD787);
  static const Color grey = Color(0xffD9D9D9);
  static const Color purple = Color(0xFF8E24AA);
  static const Color field = Color(0xffF3F3F3);
  static const Color primarycolor = Color(0xff7E1F8D);

  static const Color fieldT = Color(0xff9A9A9A);
  static const Color pink = Color(0xffF6BCFF);
  static const Color pGreen = Color(0xff22AA2B);
  static const Color lightGreen = Color(0xffEAFFE1);
  static const Color lineGrey = Color(0xffF2EFEF);
  static const Color coursePink = Color(0xffFFEAEA);
  static const Color pBrown = Color(0xff934B4B);
  static const Color study = Color(0xffFCE9FF);
  static const Color dubt = Color(0xffDB4655);
  static const Color completed = Color(0xff097B11);
  static const Color dubt2 = Color(0xffEE7480);
  static const Color startTest = Color(0xffAFEAFF);
  static const Color startButton = Color(0xff005371);
  static const Color cTest = Color(0xffD7D8FF);
  static const Color testTitle = Color(0xff421C8E);
  static const Color tabPink = Color(0xffFADCFF);
  static const Color bMedium = Color(0xffFA990E);
  static const Color medium = Color(0xffFFF4D1);
  static const Color leaveField = Color(0xffE7E6E6);
  static const Color leaveGrey = Color(0xff757575);
  static const Color logOut = Color(0xffDB4655);
  static const Color float = Color(0xffEE85FF);
  static const Color black = Colors.black;
  static const Color white = Colors.white;
  static const Color subTitle = Color(0xff858585);
  static const Color tile = Color(0xffF4F4F4);
  static const Color switchRed = Color(0xffAD2409);
  static const Color cloud = Color(0xffFEF5FF);
  static const Color sCloud = Color(0xffDCFFEA);
  static const Color trash = Color(0xffE40202);




  static const Color draft = Color(0xffEEEEEE);
  static const Color mockGrey = Color(0xff545454);

}