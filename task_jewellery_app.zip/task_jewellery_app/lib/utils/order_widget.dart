import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import 'package:task_jewellery_app/utils/appColours.dart';

class OrderedCard extends StatelessWidget {
  final String orderNum;
  final String customerName;
  final String contact;
  final String imageUrl;

  const OrderedCard({
    super.key,
    required this.orderNum,
    required this.customerName,
    required this.contact,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      color: Colors.white,
      margin: EdgeInsets.symmetric(horizontal: Get.width * 0.04, vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(Get.width * 0.04),
        child: Row(
          children: [
            Container(
              height: Get.height*0.1,
              width: Get.width*0.2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                color: Colors.white,
              ),
           child:  Image(
              image: NetworkImage("https://m.media-amazon.com/images/I/711F8TIUaLL._AC_UY1100_.jpg"), // Replace with your image asset
              fit: BoxFit.contain,
            ),),
            SizedBox(width: Get.width * 0.04),
            // Order details
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Order #: $orderNum",
                  style: GoogleFonts.poppins(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  "Name: $customerName",

                  style: GoogleFonts.poppins(fontSize: 14.0,fontWeight: FontWeight.w600,color: AppColours.fieldT),
                ),
                SizedBox(height: 4),
                Text(
                  "Contact: $contact",
                  style: GoogleFonts.poppins(fontSize: 14.0,fontWeight: FontWeight.w600,color: AppColours.pGreen),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
