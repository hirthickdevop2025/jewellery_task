import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/snackbar/snackbar.dart';

class AppComponents{
  static void appSnackbar({required String title,required String message, required bool success }) {
    Color backgroundColor;
    switch (success) {
      case true:
        backgroundColor = Colors.green;
        break;
      case false:
        backgroundColor = Colors.red;
        break;
    }
    Get.closeAllSnackbars();
    Get.snackbar(margin: const EdgeInsets.all(16),
      title,
      message,
      duration: const Duration(seconds: 2),
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: backgroundColor,
      colorText: Colors.white,
    );
  }
}