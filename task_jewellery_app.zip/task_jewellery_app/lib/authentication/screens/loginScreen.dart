

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/authentication/screens/forgetPssword.dart';

import '../../main.dart';
import '../../utils/appColours.dart';
import '../../utils/app_components.dart';

class LoginScreen extends StatelessWidget {

  const LoginScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Center(
              child: SizedBox(
                height: Get.height * 0.2,
                  child:  Image(image: NetworkImage("https://www.onlinelogomaker.com/blog/wp-content/uploads/2017/09/jewelry-logo-design.jpg")),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Welcome to ",
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600, fontSize: 16.0.sp),
                ),
                Text(
                  "Demo Jewellery",
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                      fontSize: 16.0.sp,
                      color: AppColours.purple),
                ),
              ],
            ),

            SizedBox(
              height: Get.height * 0.02,
            ),
            commonTextField(
                name: "Email",
                prefixIcon: Icon(Icons.email_rounded,color: AppColours.fieldT,),
                label: "Enter your Email"),
            SizedBox(
              height: Get.height * 0.02,
            ),
            CommonPasswordField(name: 'Password', prefixIcon: Icon(Icons.lock,color: AppColours.fieldT,), label: 'Enter your password',),
            InkWell(
              onTap: () {
                Get.to(ForgetPassword());
              },
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20, right: 20, top: 10, bottom: 10),
                child: Text(
                  "Forget password?",
                  style: GoogleFonts.poppins(
                      color: AppColours.purple,
                      fontWeight: FontWeight.w500,
                      fontSize: 10.0.sp),
                ),
              ),
            ),
            SizedBox(
              height: Get.height * 0.02,
            ),
            commonButton(
            text: "Login",
            onTap: () {
              Get.to(MainHomeScreen());
                  },
               )
          ],
        ),
      ),
    );
  }
}
