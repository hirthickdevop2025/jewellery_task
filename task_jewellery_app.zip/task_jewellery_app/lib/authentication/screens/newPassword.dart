import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/authentication/screens/loginScreen.dart';

import '../../utils/appColours.dart';
import '../../utils/app_components.dart';


class NewPassword extends StatefulWidget {

   NewPassword({super.key});

  @override
  State<NewPassword> createState() => _NewPasswordState();
}


class _NewPasswordState extends State<NewPassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColours.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "New Password",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
            onTap: () {
              Get.back();
            },
           child:   Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(

          children: [
            SizedBox(
              height: Get.height * 0.07,
            ),
            CommonPasswordField(name: 'New Password', prefixIcon: Icon(Icons.lock,color: AppColours.fieldT,), label: 'Enter your password',),

            SizedBox(
              height: Get.height * 0.05,
            ),
            commonButton(
              text: "Update password",
              onTap: () {
                Get.to(LoginScreen());
              },
            )
          ],
        ),
      ),
    );
  }
}

