

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:task_jewellery_app/authentication/screens/verification.dart';
import 'package:task_jewellery_app/utils/appColours.dart';

import '../../utils/app_components.dart';

class ForgetPassword extends StatelessWidget {


  ForgetPassword({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Forget Password",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
            onTap: () {
              Get.back();
            },
            child: Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: Get.height * 0.07,
            ),
            commonTextField(
                name: "Email",
                prefixIcon: Icon(Icons.email_rounded,color: AppColours.fieldT,),
                label: "Enter your Email"),
            SizedBox(
              height: Get.height * 0.03,
            ),
            commonButton(
              text: "Send Code",
              onTap: () {
                Get.to(Verification());
              },
            )

          ],
        ),
      ),
    );
  }

}
