import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:pinput/pinput.dart';
import 'package:task_jewellery_app/authentication/screens/newPassword.dart';

import '../../utils/appColours.dart';
import '../../utils/app_components.dart';

class Verification extends StatelessWidget {

  Verification({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Verification",
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.w600, fontSize: 16.0.sp),
        ),
        leading: Transform.scale(
          scale: 0.6,
          child: InkWell(
            onTap: () {
              Get.back();
            },
           child: Icon(Icons.keyboard_arrow_left,color: AppColours.black,size: 60.0.w,)
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: Get.height * 0.1),
            Padding(
              padding: const EdgeInsets.only(left: 40, right: 40),
              child: Center(
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "We’ve sent a ",
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                          fontSize: 16.0.sp,
                        ),
                      ),
                      TextSpan(
                        text: "4-digit code ",
                        style: GoogleFonts.poppins(
                          color: AppColours.purple,
                          fontWeight: FontWeight.w600,
                          fontSize: 16.0.sp,
                        ),
                      ),
                      TextSpan(
                        text: "to email",
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: 16.0.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 50, right: 50, top: 40),
              child: Center(
                child: Pinput(
                  controller: TextEditingController(), // Link to otpController
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  length: 4,
                  defaultPinTheme: PinTheme(
                    textStyle: GoogleFonts.poppins(
                        fontWeight: FontWeight.w500,
                        color: Colors.black, // Changed to black for visibility
                        fontSize: 20.0.sp),
                    width: Get.width * 0.14,
                    height: Get.height * 0.065,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  focusedPinTheme: PinTheme(
                    textStyle: GoogleFonts.poppins(
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                        fontSize: 20.0.sp),
                    width: Get.width * 0.14,
                    height: Get.height * 0.065,
                    decoration: BoxDecoration(
                      color: AppColours.purple,
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  submittedPinTheme: PinTheme(
                    textStyle: GoogleFonts.poppins(
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                        fontSize: 20.0.sp),
                    width: Get.width * 0.14,
                    height: Get.height * 0.065,
                    decoration: BoxDecoration(
                      color: AppColours.purple,
                      borderRadius: BorderRadius.circular(50),
                    ),
                  ),
                  onCompleted: (pin) {

                  },
                ),
              ),
            ),
            SizedBox(height: Get.height * 0.05),
            commonButton(
              text: "Submit",
              onTap: () {
                Get.to(NewPassword());
              },
            ),
            SizedBox(height: Get.height * 0.02),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Didn’t receive code? ",
                  style: GoogleFonts.poppins(
                      color: Colors.grey[700],
                      fontWeight: FontWeight.w400,
                      fontSize: 14.0.sp),
                ),
                GestureDetector(
                  onTap: () {

                  },
                  child: Text(
                    "Resend Code",
                    style: GoogleFonts.poppins(
                        color: AppColours.purple,
                        fontWeight: FontWeight.w500,
                        fontSize: 14.0.sp),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

}
